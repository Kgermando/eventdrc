jQuery(document).ready(function() {
    jQuery('#mycarousel').jcarousel();
	 jQuery('#mycarousel1').jcarousel();
});